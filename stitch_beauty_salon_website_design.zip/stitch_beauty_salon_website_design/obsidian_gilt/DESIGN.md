---
name: Obsidian & Gilt
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#d0c5af'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#99907c'
  outline-variant: '#4d4635'
  surface-tint: '#e9c349'
  primary: '#f2ca50'
  on-primary: '#3c2f00'
  primary-container: '#d4af37'
  on-primary-container: '#554300'
  inverse-primary: '#735c00'
  secondary: '#e7c35a'
  on-secondary: '#3d2f00'
  secondary-container: '#896c00'
  on-secondary-container: '#fff3dc'
  tertiary: '#d0cec9'
  on-tertiary: '#30312d'
  tertiary-container: '#b4b3ae'
  on-tertiary-container: '#454541'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffe088'
  primary-fixed-dim: '#e9c349'
  on-primary-fixed: '#241a00'
  on-primary-fixed-variant: '#574500'
  secondary-fixed: '#ffe08b'
  secondary-fixed-dim: '#e7c35a'
  on-secondary-fixed: '#241a00'
  on-secondary-fixed-variant: '#584400'
  tertiary-fixed: '#e4e2dd'
  tertiary-fixed-dim: '#c8c6c1'
  on-tertiary-fixed: '#1b1c18'
  on-tertiary-fixed-variant: '#474743'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 26px
    fontWeight: '500'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 28px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.08em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.12em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1.25rem
  margin-sm: 1rem
  margin-lg: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.25rem
---

## Brand & Style

This design system embodies an intimate, ultra-luxe sanctuary for bespoke hair design, high-fashion styling, and couture beauty services. The atmosphere is nocturnal, quiet, and opulent—evoking the sensory ambiance of private salon suites lined in fluted smoked glass, black marble, and brushed champagne gold fixtures.

The visual direction pairs dark minimalism with tactile luxury. It eschews clinical bright whites in favor of an obsidian nightscape illuminated by metallic accents, soft candlelight gradients, and ivory text. Interactions feel measured, silky, and deliberate, treating mobile appointment curation and treatment discovery not as a transaction, but as a concierge-level ritual.

## Colors

The palette establishes an opulent contrast between deep, atmospheric darks and reflective golden metal:

- **Base Darks**: 
  - Obsidian Core (`#121212`): Foundational screen canvas.
  - Deep Espresso/Smoked Slate (`#1A1A1A`): Elevated structural surface for containers, cards, and modal sheets.
  - Layered Charcoal (`#242322`): Subtle intermediate highlight surface for elevated sub-panels and active states.
- **Precious Metals**:
  - Classic Champagne Gold (`#D4AF37`): Primary brand signature, used for definitive actions, active states, key icons, and focused strokes.
  - Radiant Gold Highlight (`#E5C158`): Hover, active tap states, and fine gradient reflections.
  - Pale Shimmer Gold (`#F3E5AB`): Delicate rim lights, badge backgrounds, and accent sparkles.
- **Neutrals & Typography**:
  - Soft Muted Ivory (`#F8F6F0`): Primary high-contrast body and title readability, avoiding the stark sterility of pure white.
  - Smoked Taupe (`#A8A29E`): Secondary captions, inactive tabs, and meta descriptions.
  - Deep Hairline Border (`rgba(212, 175, 55, 0.2)`): Hairline gold definition framing dark containers.

## Typography

The type system blends editorial romance with ergonomic mobile clarity.

- **Headlines & Editorial Statements**: Set in **Playfair Display**. Features delicate serifs, generous letterforms, and high visual contrast. Reserved for screen intros, service category names, artist monikers, and quote banners.
- **Functional Body & Interfaces**: Set in **Plus Jakarta Sans**. Provides geometric crispness and open apertures that remain legible against rich dark backgrounds without visual bleed.
- **Pricing, Tags, and Overlines**: Rendered in uppercase **Plus Jakarta Sans** with expanded tracking (`0.08em` to `0.12em`), providing a structured, bespoke luxury feel for curation tiers and service durations.

## Layout & Spacing

A 4-column fluid mobile grid anchored by a 4px/8px incremental spacing scale. The layout utilizes safe zones to optimize bottom-sheet flows and single-thumb ergonomics for booking appointments on mobile screens.

- **Mobile (<600px)**: 4-column layout with `1.25rem` outer margins and `0.75rem` gutters. Interactive triggers and primary CTAs sit within a thumb-accessible fixed bottom bar elevated over ambient page content.
- **Tablet (600px–1023px)**: 8-column layout with `1.5rem` outer margins. Booking flows transition into a centered split card sheet (preview on left, calendar/slots on right).
- **Desktop (≥1024px)**: 12-column layout centered at a maximum content width of 1140px, framed with `2rem` margins.

## Elevation & Depth

Visual depth avoids generic gray drop shadows, using deep, warm black layers illuminated by soft metallic refraction:

- **Level 1 (Cards & Inset Wells)**: Background `#1A1A1A` with a 1px border of `rgba(212, 175, 55, 0.15)` and soft diffused shadow: `0 8px 24px -4px rgba(0, 0, 0, 0.6)`.
- **Level 2 (Floating Action Bars & Selection Modals)**: Glassmorphic deep charcoal `rgba(26, 26, 26, 0.85)` with `16px` backdrop blur, a 1px top border of `rgba(229, 193, 88, 0.35)`, and drop shadow: `0 16px 36px -6px rgba(0, 0, 0, 0.8)`.
- **Gold Ring Glow (Active/Selected States)**: Selected booking dates, specialist avatars, and treatment tiers trigger an ambient halo: `0 0 0 1px #D4AF37, 0 0 16px rgba(212, 175, 55, 0.3)`.

## Shapes

The design system embraces a refined architectural soft geometry (`roundedness: 1`), featuring deliberate `0.25rem` corners on inputs and compact tags, transitioning up to `0.5rem` (`rounded-lg`) on service cards and bottom sheets. 

Sharp, precision edges communicate craftsmanship and bespoke tailoring, avoiding overly bubbly or playful radii while remaining soft to touch. Circular forms are reserved exclusively for practitioner avatars, date-selection pips, and floating luxury icon medallions.

## Components

### Buttons
- **Primary Luxury Action**: Polished metallic fill utilizing a subtle horizontal gradient from `#D4AF37` to `#E5C158` with deep obsidian text (`#121212`), semi-bold typography, uppercase letter spacing, and a height of 52px for comfortable thumb targeting.
- **Secondary / Ghost Luxury**: Deep charcoal background (`#1A1A1A`) with a crisp 1px gold hairline border (`rgba(212, 175, 55, 0.4)`), soft ivory text (`#F8F6F0`), and gold hover glow.

### Cards & Service Tiles
- Structured containers with `#1A1A1A` background, `0.5rem` corner radius, and subtle hairline border (`rgba(212, 175, 55, 0.15)`).
- Images feature a subtle dark vignette overlay to ensure text placed above them retains full legibility. Includes service duration in tracked uppercase and pricing highlighted in `#E5C158`.

### Chips & Filter Tags
- Pill-shaped or soft-rect filters for selecting master stylists, treatment types (e.g., "Balayage", "Gloss & Tone", "Ritual Hair Spa").
- Inactive: Frosted charcoal base with taupe label.
- Selected: Solid `#D4AF37` outline, ivory label, and a warm `rgba(212, 175, 55, 0.15)` filled background.

### Input Fields & Selectors
- Background of `#161616` with a recessed appearance, 1px perimeter border in `rgba(255, 255, 255, 0.1)`.
- When focused, the border transitions to `#D4AF37` with an ambient glow (`0 0 8px rgba(212, 175, 55, 0.25)`), and labels float upwards in champagne gold.

### Selection Controls (Radio / Time Slots)
- Time booking pips display as architectural blocks. Available slots feature an ivory timestamp; selected slots shift to `#1A1A1A` container framed with an active gold ring glow and gold typographic accent.

### Bespoke Domain Components
- **Artisan Bio Strip**: Compact horizontal tile spotlighting the Master Stylist’s portrait with a circular gold rim, specialty tags, and review badge.
- **Concierge Booking Bar**: Fixed bottom bar housing service summary, total price, and the "Reserve Appointment" CTA, separated from the scrollable canvas with a gold hairline highlight.